"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Scissors, Menu, User } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useState } from "react"

interface MainNavProps {
  userRole?: "admin" | "employee" | "customer"
}

export function MainNav({ userRole = "customer" }: MainNavProps) {
  const pathname = usePathname()
  const [isOpen, setIsOpen] = useState(false)

  const routes = [
    {
      href: "/dashboard",
      label: "Dashboard",
      active: pathname === "/dashboard",
    },
    {
      href: "/booking",
      label: "Book Appointment",
      active: pathname === "/booking",
    },
    {
      href: "/market",
      label: "Shop",
      active: pathname === "/market",
    },
    {
      href: "/about",
      label: "About",
      active: pathname === "/about",
    },
  ]

  // Admin-specific routes
  const adminRoutes = [
    {
      href: "/admin/products",
      label: "Manage Products",
      active: pathname === "/admin/products",
    },
    {
      href: "/admin/users",
      label: "Manage Users",
      active: pathname === "/admin/users",
    },
  ]

  // Employee-specific routes
  const employeeRoutes = [
    {
      href: "/employee/appointments",
      label: "My Appointments",
      active: pathname === "/employee/appointments",
    },
  ]

  // Determine which routes to show based on user role
  const navRoutes = [...routes]
  if (userRole === "admin") {
    navRoutes.push(...adminRoutes)
  } else if (userRole === "employee") {
    navRoutes.push(...employeeRoutes)
  }

  return (
    <div className="border-b">
      <div className="flex h-16 items-center px-4">
        <Link href="/" className="flex items-center gap-2 font-bold text-xl mr-6">
          <Scissors className="h-6 w-6" />
          <span>BarberBook</span>
        </Link>
        <nav className="hidden md:flex items-center space-x-4 lg:space-x-6 mx-6">
          {navRoutes.map((route) => (
            <Link
              key={route.href}
              href={route.href}
              className={cn(
                "text-sm font-medium transition-colors hover:text-primary",
                route.active ? "text-primary" : "text-muted-foreground",
              )}
            >
              {route.label}
            </Link>
          ))}
        </nav>
        <div className="md:hidden flex items-center">
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left">
              <Link href="/" className="flex items-center gap-2 font-bold text-xl mb-6">
                <Scissors className="h-6 w-6" />
                <span>BarberBook</span>
              </Link>
              <nav className="flex flex-col space-y-4">
                {navRoutes.map((route) => (
                  <Link
                    key={route.href}
                    href={route.href}
                    className={cn(
                      "text-sm font-medium transition-colors hover:text-primary",
                      route.active ? "text-primary" : "text-muted-foreground",
                    )}
                    onClick={() => setIsOpen(false)}
                  >
                    {route.label}
                  </Link>
                ))}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
        <div className="ml-auto flex items-center space-x-4">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <User className="h-5 w-5" />
                <span className="sr-only">User menu</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem asChild>
                <Link href="/profile">Profile</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/appointments">My Appointments</Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link href="/auth/login">Sign out</Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  )
}

