import { MainNav } from "@/components/main-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Clock, ShoppingBag, Users, Scissors, BarChart } from "lucide-react"
import Link from "next/link"

export default function DashboardPage() {
  // This would normally come from authentication
  const userRole = "customer" // "admin", "employee", or "customer"

  return (
    <div className="flex min-h-screen flex-col">
      <MainNav userRole={userRole as any} />
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
          <div className="flex items-center gap-2">
            {userRole === "customer" && (
              <Link href="/booking">
                <Button className="gap-2">
                  <Calendar className="h-4 w-4" />
                  Book Appointment
                </Button>
              </Link>
            )}
          </div>
        </div>

        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="appointments">Appointments</TabsTrigger>
            {userRole === "customer" && <TabsTrigger value="orders">Orders</TabsTrigger>}
            {userRole === "admin" && <TabsTrigger value="analytics">Analytics</TabsTrigger>}
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
              {userRole === "customer" && (
                <>
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Upcoming Appointments</CardTitle>
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">2</div>
                      <p className="text-xs text-muted-foreground">Next: Tomorrow at 2:30 PM</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Recent Orders</CardTitle>
                      <ShoppingBag className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">3</div>
                      <p className="text-xs text-muted-foreground">Last order: 3 days ago</p>
                    </CardContent>
                  </Card>
                </>
              )}

              {userRole === "employee" && (
                <>
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Today's Appointments</CardTitle>
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">8</div>
                      <p className="text-xs text-muted-foreground">Next: In 30 minutes</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Weekly Schedule</CardTitle>
                      <Clock className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">32 hrs</div>
                      <p className="text-xs text-muted-foreground">Mon-Fri, 9 AM - 5 PM</p>
                    </CardContent>
                  </Card>
                </>
              )}

              {userRole === "admin" && (
                <>
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Total Appointments</CardTitle>
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">245</div>
                      <p className="text-xs text-muted-foreground">+22% from last month</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                      <BarChart className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">$12,234</div>
                      <p className="text-xs text-muted-foreground">+15% from last month</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Active Users</CardTitle>
                      <Users className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">573</div>
                      <p className="text-xs text-muted-foreground">+48 new this week</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Product Sales</CardTitle>
                      <ShoppingBag className="h-4 w-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">124</div>
                      <p className="text-xs text-muted-foreground">+8% from last week</p>
                    </CardContent>
                  </Card>
                </>
              )}
            </div>

            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
              <Card className="col-span-4">
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {userRole === "customer" && (
                      <>
                        <div className="flex items-center gap-4">
                          <div className="rounded-full p-2 bg-primary/10">
                            <Calendar className="h-4 w-4 text-primary" />
                          </div>
                          <div className="space-y-1">
                            <p className="text-sm font-medium">Appointment Booked</p>
                            <p className="text-xs text-muted-foreground">
                              You booked an appointment with John Doe for March 15, 2:30 PM
                            </p>
                          </div>
                          <div className="ml-auto text-xs text-muted-foreground">2 days ago</div>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="rounded-full p-2 bg-primary/10">
                            <ShoppingBag className="h-4 w-4 text-primary" />
                          </div>
                          <div className="space-y-1">
                            <p className="text-sm font-medium">Order Placed</p>
                            <p className="text-xs text-muted-foreground">You ordered Premium Hair Wax and Beard Oil</p>
                          </div>
                          <div className="ml-auto text-xs text-muted-foreground">3 days ago</div>
                        </div>
                      </>
                    )}

                    {userRole === "employee" && (
                      <>
                        <div className="flex items-center gap-4">
                          <div className="rounded-full p-2 bg-primary/10">
                            <Calendar className="h-4 w-4 text-primary" />
                          </div>
                          <div className="space-y-1">
                            <p className="text-sm font-medium">New Appointment</p>
                            <p className="text-xs text-muted-foreground">
                              Jane Smith booked an appointment with you for tomorrow at 3:00 PM
                            </p>
                          </div>
                          <div className="ml-auto text-xs text-muted-foreground">1 hour ago</div>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="rounded-full p-2 bg-primary/10">
                            <Clock className="h-4 w-4 text-primary" />
                          </div>
                          <div className="space-y-1">
                            <p className="text-sm font-medium">Schedule Updated</p>
                            <p className="text-xs text-muted-foreground">
                              Your schedule for next week has been updated
                            </p>
                          </div>
                          <div className="ml-auto text-xs text-muted-foreground">Yesterday</div>
                        </div>
                      </>
                    )}

                    {userRole === "admin" && (
                      <>
                        <div className="flex items-center gap-4">
                          <div className="rounded-full p-2 bg-primary/10">
                            <Users className="h-4 w-4 text-primary" />
                          </div>
                          <div className="space-y-1">
                            <p className="text-sm font-medium">New User Registration</p>
                            <p className="text-xs text-muted-foreground">5 new users registered in the last 24 hours</p>
                          </div>
                          <div className="ml-auto text-xs text-muted-foreground">Today</div>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="rounded-full p-2 bg-primary/10">
                            <ShoppingBag className="h-4 w-4 text-primary" />
                          </div>
                          <div className="space-y-1">
                            <p className="text-sm font-medium">Product Stock Alert</p>
                            <p className="text-xs text-muted-foreground">
                              Premium Hair Wax is running low on stock (3 remaining)
                            </p>
                          </div>
                          <div className="ml-auto text-xs text-muted-foreground">2 hours ago</div>
                        </div>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
              <Card className="col-span-3">
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                  <CardDescription>Frequently used actions for your role</CardDescription>
                </CardHeader>
                <CardContent className="grid gap-2">
                  {userRole === "customer" && (
                    <>
                      <Button className="w-full justify-start" variant="outline" asChild>
                        <Link href="/booking" className="flex items-center gap-2">
                          <Calendar className="h-4 w-4" />
                          Book New Appointment
                        </Link>
                      </Button>
                      <Button className="w-full justify-start" variant="outline" asChild>
                        <Link href="/market" className="flex items-center gap-2">
                          <ShoppingBag className="h-4 w-4" />
                          Browse Products
                        </Link>
                      </Button>
                    </>
                  )}

                  {userRole === "employee" && (
                    <>
                      <Button className="w-full justify-start" variant="outline" asChild>
                        <Link href="/employee/appointments" className="flex items-center gap-2">
                          <Calendar className="h-4 w-4" />
                          View Today's Schedule
                        </Link>
                      </Button>
                      <Button className="w-full justify-start" variant="outline" asChild>
                        <Link href="/employee/profile" className="flex items-center gap-2">
                          <Scissors className="h-4 w-4" />
                          Update Services
                        </Link>
                      </Button>
                    </>
                  )}

                  {userRole === "admin" && (
                    <>
                      <Button className="w-full justify-start" variant="outline" asChild>
                        <Link href="/admin/products" className="flex items-center gap-2">
                          <ShoppingBag className="h-4 w-4" />
                          Manage Products
                        </Link>
                      </Button>
                      <Button className="w-full justify-start" variant="outline" asChild>
                        <Link href="/admin/users" className="flex items-center gap-2">
                          <Users className="h-4 w-4" />
                          Manage Users
                        </Link>
                      </Button>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="appointments" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Your Appointments</CardTitle>
                <CardDescription>
                  {userRole === "customer"
                    ? "View and manage your upcoming appointments"
                    : userRole === "employee"
                      ? "Your schedule for the upcoming days"
                      : "All appointments in the system"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="rounded-md border">
                    <div className="grid grid-cols-4 p-4 font-medium">
                      <div>Date & Time</div>
                      {userRole === "customer" ? <div>Barber</div> : <div>Client</div>}
                      <div>Service</div>
                      <div className="text-right">Actions</div>
                    </div>
                    <div className="divide-y">
                      <div className="grid grid-cols-4 items-center p-4">
                        <div>Mar 15, 2:30 PM</div>
                        {userRole === "customer" ? <div>John Doe</div> : <div>Alex Johnson</div>}
                        <div>Haircut & Beard Trim</div>
                        <div className="flex justify-end gap-2">
                          <Button size="sm" variant="outline">
                            Reschedule
                          </Button>
                          <Button size="sm" variant="destructive">
                            Cancel
                          </Button>
                        </div>
                      </div>
                      <div className="grid grid-cols-4 items-center p-4">
                        <div>Mar 22, 3:00 PM</div>
                        {userRole === "customer" ? <div>Sarah Smith</div> : <div>Michael Brown</div>}
                        <div>Premium Haircut</div>
                        <div className="flex justify-end gap-2">
                          <Button size="sm" variant="outline">
                            Reschedule
                          </Button>
                          <Button size="sm" variant="destructive">
                            Cancel
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {userRole === "customer" && (
            <TabsContent value="orders" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Your Orders</CardTitle>
                  <CardDescription>View your order history and track current orders</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="rounded-md border">
                      <div className="grid grid-cols-4 p-4 font-medium">
                        <div>Order Date</div>
                        <div>Products</div>
                        <div>Status</div>
                        <div className="text-right">Total</div>
                      </div>
                      <div className="divide-y">
                        <div className="grid grid-cols-4 items-center p-4">
                          <div>Mar 10, 2024</div>
                          <div>Premium Hair Wax, Beard Oil</div>
                          <div className="flex items-center">
                            <span className="rounded-full h-2 w-2 bg-green-500 mr-2"></span>
                            Delivered
                          </div>
                          <div className="text-right">$45.99</div>
                        </div>
                        <div className="grid grid-cols-4 items-center p-4">
                          <div>Feb 25, 2024</div>
                          <div>Styling Brush, Shampoo</div>
                          <div className="flex items-center">
                            <span className="rounded-full h-2 w-2 bg-green-500 mr-2"></span>
                            Delivered
                          </div>
                          <div className="text-right">$32.50</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )}

          {userRole === "admin" && (
            <TabsContent value="analytics" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Business Analytics</CardTitle>
                  <CardDescription>Overview of your business performance</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] flex items-center justify-center border rounded-md">
                    <p className="text-muted-foreground">Analytics charts would be displayed here</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )}
        </Tabs>
      </div>
    </div>
  )
}

