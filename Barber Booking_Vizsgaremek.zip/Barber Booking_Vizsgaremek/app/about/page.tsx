import { MainNav } from "@/components/main-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Clock, MapPin, Phone, Mail, Instagram, Facebook, Twitter } from "lucide-react"
import Link from "next/link"

export default function AboutPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <MainNav />
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">About Us</h2>
          <Link href="/booking">
            <Button>Book Now</Button>
          </Link>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <Card className="h-full">
              <CardHeader>
                <CardTitle>Our Story</CardTitle>
                <CardDescription>Crafting perfect styles since 2010</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
              <p>
                You can find the shop in a small street in downtown Budapest, where Bence and Patrik, two 19-year-old barbers, await their guests. Here, not only haircuts take place, but also a real style battle.

Bence is a master of cutting, bringing the latest trends, while Patrik is a guru of classic shaving. Both know that hair is not just hair – it is an expression of masculinity. The atmosphere is relaxed and direct, where everyone feels at home, and in addition to good conversations, the hairstyles also stand out.

If you are looking for a truly masculine place, where style and fun meet, this is the place for you. Come in and experience how the barbers shape your hair!</p>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card className="h-full">
              <div className="aspect-video w-full overflow-hidden">
                <img
                  src="/placeholder.svg?height=400&width=800"
                  alt="Barber shop interior"
                  className="object-cover w-full h-full"
                />
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-2">Premium Grooming Experience</h3>
                <p className="text-muted-foreground">
                  Our modern facilities and skilled barbers ensure you get the best grooming experience possible. We use
                  only premium products and tools to deliver exceptional results.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        <Tabs defaultValue="hours" className="mt-6">
          <TabsList>
            <TabsTrigger value="hours">Hours & Location</TabsTrigger>
            <TabsTrigger value="team">Our Team</TabsTrigger>
            <TabsTrigger value="contact">Contact Us</TabsTrigger>
          </TabsList>

          <TabsContent value="hours" className="mt-4 space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5" /> Opening Hours
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Monday - Friday</span>
                      <span>9:00 AM - 7:00 PM</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Saturday</span>
                      <span>9:00 AM - 5:00 PM</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Sunday</span>
                      <span>Closed</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="h-5 w-5" /> Location
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <p>123 Main Street</p>
                  <p>New York, NY 10001</p>
                  <div className="aspect-video w-full mt-4 bg-muted rounded-md flex items-center justify-center">
                    <p className="text-muted-foreground">Map would be displayed here</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="team" className="mt-4">
            <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
              <Card>
                <div className="aspect-square">
                  <img
                    src="/placeholder.svg?height=300&width=300"
                    alt="John Doe"
                    className="object-cover w-full h-full"
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="font-bold">John Doe</h3>
                  <p className="text-sm text-muted-foreground">Master Barber</p>
                  <p className="text-sm mt-2">Specializing in classic cuts and hot towel shaves.</p>
                </CardContent>
              </Card>

              <Card>
                <div className="aspect-square">
                  <img
                    src="/placeholder.svg?height=300&width=300"
                    alt="Sarah Smith"
                    className="object-cover w-full h-full"
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="font-bold">Sarah Smith</h3>
                  <p className="text-sm text-muted-foreground">Style Specialist</p>
                  <p className="text-sm mt-2">Expert in modern styles and precision fades.</p>
                </CardContent>
              </Card>

              <Card>
                <div className="aspect-square">
                  <img
                    src="/placeholder.svg?height=300&width=300"
                    alt="Mike Johnson"
                    className="object-cover w-full h-full"
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="font-bold">Mike Johnson</h3>
                  <p className="text-sm text-muted-foreground">Beard Specialist</p>
                  <p className="text-sm mt-2">Dedicated to perfect beard grooming and styling.</p>
                </CardContent>
              </Card>

              <Card>
                <div className="aspect-square">
                  <img
                    src="/placeholder.svg?height=300&width=300"
                    alt="Emily Davis"
                    className="object-cover w-full h-full"
                  />
                </div>
                <CardContent className="p-4">
                  <h3 className="font-bold">Emily Davis</h3>
                  <p className="text-sm text-muted-foreground">Senior Barber</p>
                  <p className="text-sm mt-2">Specializes in fades, tapers, and textured cuts.</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="contact" className="mt-4 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Get in Touch</CardTitle>
                <CardDescription>Have questions? We're here to help.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <Phone className="h-5 w-5 text-primary" />
                      <span>(123) 456-7890</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="h-5 w-5 text-primary" />
                      <span>info@barberbook.com</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="h-5 w-5 text-primary" />
                      <span>123 Main Street, New York, NY 10001</span>
                    </div>
                    <div className="flex gap-4 mt-6">
                      <Button variant="outline" size="icon">
                        <Instagram className="h-4 w-4" />
                        <span className="sr-only">Instagram</span>
                      </Button>
                      <Button variant="outline" size="icon">
                        <Facebook className="h-4 w-4" />
                        <span className="sr-only">Facebook</span>
                      </Button>
                      <Button variant="outline" size="icon">
                        <Twitter className="h-4 w-4" />
                        <span className="sr-only">Twitter</span>
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="grid gap-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label htmlFor="first-name" className="text-sm font-medium">
                            First name
                          </label>
                          <input id="first-name" className="w-full p-2 rounded-md border" placeholder="John" />
                        </div>
                        <div className="space-y-2">
                          <label htmlFor="last-name" className="text-sm font-medium">
                            Last name
                          </label>
                          <input id="last-name" className="w-full p-2 rounded-md border" placeholder="Doe" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="email" className="text-sm font-medium">
                          Email
                        </label>
                        <input
                          id="email"
                          type="email"
                          className="w-full p-2 rounded-md border"
                          placeholder="john@example.com"
                        />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="message" className="text-sm font-medium">
                          Message
                        </label>
                        <textarea
                          id="message"
                          className="w-full p-2 rounded-md border min-h-[100px]"
                          placeholder="How can we help you?"
                        />
                      </div>
                      <Button>Send Message</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

