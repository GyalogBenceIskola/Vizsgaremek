"use client"

import { useState } from "react"
import { MainNav } from "@/components/main-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Plus, Pencil, Trash2, Search } from "lucide-react"

// Mock data for products
const initialProducts = [
  {
    id: 1,
    name: "Premium Hair Wax",
    category: "styling",
    price: 24.99,
    stock: 45,
    image: "/placeholder.svg?height=300&width=300",
    description: "High-hold, low-shine hair wax for the perfect style.",
  },
  {
    id: 2,
    name: "Beard Oil",
    category: "beard",
    price: 19.99,
    stock: 32,
    image: "/placeholder.svg?height=300&width=300",
    description: "Nourishing beard oil for a soft, manageable beard.",
  },
  {
    id: 3,
    name: "Styling Brush",
    category: "accessories",
    price: 15.99,
    stock: 28,
    image: "/placeholder.svg?height=300&width=300",
    description: "Professional styling brush for perfect hair styling.",
  },
  {
    id: 4,
    name: "Premium Shampoo",
    category: "haircare",
    price: 22.99,
    stock: 50,
    image: "/placeholder.svg?height=300&width=300",
    description: "Sulfate-free shampoo for healthy, vibrant hair.",
  },
]

export default function AdminProductsPage() {
  const [products, setProducts] = useState(initialProducts)
  const [searchQuery, setSearchQuery] = useState("")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [currentProduct, setCurrentProduct] = useState<any>(null)
  const [newProduct, setNewProduct] = useState({
    name: "",
    category: "",
    price: "",
    stock: "",
    description: "",
    featured: false,
  })

  const filteredProducts = products.filter(
    (product) =>
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleAddProduct = () => {
    const productToAdd = {
      id: products.length + 1,
      name: newProduct.name,
      category: newProduct.category,
      price: Number.parseFloat(newProduct.price),
      stock: Number.parseInt(newProduct.stock),
      image: "/placeholder.svg?height=300&width=300",
      description: newProduct.description,
    }

    setProducts([...products, productToAdd])
    setNewProduct({
      name: "",
      category: "",
      price: "",
      stock: "",
      description: "",
      featured: false,
    })
    setIsAddDialogOpen(false)
  }

  const handleEditProduct = () => {
    if (!currentProduct) return

    setProducts(products.map((product) => (product.id === currentProduct.id ? currentProduct : product)))

    setIsEditDialogOpen(false)
    setCurrentProduct(null)
  }

  const handleDeleteProduct = (id: number) => {
    if (confirm("Are you sure you want to delete this product?")) {
      setProducts(products.filter((product) => product.id !== id))
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <MainNav userRole="admin" />
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">Manage Products</h2>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search products..."
                className="w-[200px] pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  Add Product
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>Add New Product</DialogTitle>
                  <DialogDescription>Fill in the details for the new product</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="name">Product Name</Label>
                    <Input
                      id="name"
                      value={newProduct.name}
                      onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="category">Category</Label>
                      <Select
                        value={newProduct.category}
                        onValueChange={(value) => setNewProduct({ ...newProduct, category: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="styling">Styling</SelectItem>
                          <SelectItem value="beard">Beard Care</SelectItem>
                          <SelectItem value="haircare">Hair Care</SelectItem>
                          <SelectItem value="accessories">Accessories</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-2">
                      <Label htmlFor="price">Price ($)</Label>
                      <Input
                        id="price"
                        type="number"
                        step="0.01"
                        value={newProduct.price}
                        onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="stock">Stock Quantity</Label>
                    <Input
                      id="stock"
                      type="number"
                      value={newProduct.stock}
                      onChange={(e) => setNewProduct({ ...newProduct, stock: e.target.value })}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={newProduct.description}
                      onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch
                      id="featured"
                      checked={newProduct.featured}
                      onCheckedChange={(checked) => setNewProduct({ ...newProduct, featured: checked })}
                    />
                    <Label htmlFor="featured">Featured Product</Label>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddProduct}>Add Product</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <Tabs defaultValue="all" className="space-y-4">
          <TabsList>
            <TabsTrigger value="all">All Products</TabsTrigger>
            <TabsTrigger value="styling">Styling</TabsTrigger>
            <TabsTrigger value="beard">Beard Care</TabsTrigger>
            <TabsTrigger value="haircare">Hair Care</TabsTrigger>
            <TabsTrigger value="accessories">Accessories</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Product Inventory</CardTitle>
                <CardDescription>Manage your product inventory, prices, and details</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border">
                  <div className="grid grid-cols-6 p-4 font-medium">
                    <div className="col-span-2">Product</div>
                    <div>Category</div>
                    <div>Price</div>
                    <div>Stock</div>
                    <div className="text-right">Actions</div>
                  </div>
                  <div className="divide-y">
                    {filteredProducts.length === 0 ? (
                      <div className="p-4 text-center text-muted-foreground">
                        No products found matching your search.
                      </div>
                    ) : (
                      filteredProducts.map((product) => (
                        <div key={product.id} className="grid grid-cols-6 items-center p-4">
                          <div className="col-span-2 flex items-center gap-4">
                            <img
                              src={product.image || "/placeholder.svg"}
                              alt={product.name}
                              className="h-10 w-10 rounded object-cover"
                            />
                            <div>
                              <p className="font-medium">{product.name}</p>
                              <p className="text-xs text-muted-foreground line-clamp-1">{product.description}</p>
                            </div>
                          </div>
                          <div className="capitalize">{product.category}</div>
                          <div>${product.price.toFixed(2)}</div>
                          <div>{product.stock}</div>
                          <div className="flex justify-end gap-2">
                            <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                              <DialogTrigger asChild>
                                <Button variant="outline" size="icon" onClick={() => setCurrentProduct(product)}>
                                  <Pencil className="h-4 w-4" />
                                  <span className="sr-only">Edit</span>
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="sm:max-w-[500px]">
                                {currentProduct && (
                                  <>
                                    <DialogHeader>
                                      <DialogTitle>Edit Product</DialogTitle>
                                      <DialogDescription>Update the product details</DialogDescription>
                                    </DialogHeader>
                                    <div className="grid gap-4 py-4">
                                      <div className="grid gap-2">
                                        <Label htmlFor="edit-name">Product Name</Label>
                                        <Input
                                          id="edit-name"
                                          value={currentProduct.name}
                                          onChange={(e) =>
                                            setCurrentProduct({ ...currentProduct, name: e.target.value })
                                          }
                                        />
                                      </div>
                                      <div className="grid grid-cols-2 gap-4">
                                        <div className="grid gap-2">
                                          <Label htmlFor="edit-category">Category</Label>
                                          <Select
                                            value={currentProduct.category}
                                            onValueChange={(value) =>
                                              setCurrentProduct({ ...currentProduct, category: value })
                                            }
                                          >
                                            <SelectTrigger>
                                              <SelectValue placeholder="Select category" />
                                            </SelectTrigger>
                                            <SelectContent>
                                              <SelectItem value="styling">Styling</SelectItem>
                                              <SelectItem value="beard">Beard Care</SelectItem>
                                              <SelectItem value="haircare">Hair Care</SelectItem>
                                              <SelectItem value="accessories">Accessories</SelectItem>
                                            </SelectContent>
                                          </Select>
                                        </div>
                                        <div className="grid gap-2">
                                          <Label htmlFor="edit-price">Price ($)</Label>
                                          <Input
                                            id="edit-price"
                                            type="number"
                                            step="0.01"
                                            value={currentProduct.price}
                                            onChange={(e) =>
                                              setCurrentProduct({
                                                ...currentProduct,
                                                price: Number.parseFloat(e.target.value),
                                              })
                                            }
                                          />
                                        </div>
                                      </div>
                                      <div className="grid gap-2">
                                        <Label htmlFor="edit-stock">Stock Quantity</Label>
                                        <Input
                                          id="edit-stock"
                                          type="number"
                                          value={currentProduct.stock}
                                          onChange={(e) =>
                                            setCurrentProduct({
                                              ...currentProduct,
                                              stock: Number.parseInt(e.target.value),
                                            })
                                          }
                                        />
                                      </div>
                                      <div className="grid gap-2">
                                        <Label htmlFor="edit-description">Description</Label>
                                        <Textarea
                                          id="edit-description"
                                          value={currentProduct.description}
                                          onChange={(e) =>
                                            setCurrentProduct({ ...currentProduct, description: e.target.value })
                                          }
                                        />
                                      </div>
                                    </div>
                                    <DialogFooter>
                                      <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                                        Cancel
                                      </Button>
                                      <Button onClick={handleEditProduct}>Save Changes</Button>
                                    </DialogFooter>
                                  </>
                                )}
                              </DialogContent>
                            </Dialog>
                            <Button variant="outline" size="icon" onClick={() => handleDeleteProduct(product.id)}>
                              <Trash2 className="h-4 w-4" />
                              <span className="sr-only">Delete</span>
                            </Button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Other tabs would filter by category */}
          <TabsContent value="styling" className="space-y-4">
            {/* Similar content as "all" tab but filtered */}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

