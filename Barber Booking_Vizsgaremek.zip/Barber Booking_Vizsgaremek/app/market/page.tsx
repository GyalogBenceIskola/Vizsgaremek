"use client"

import { useState } from "react"
import { MainNav } from "@/components/main-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart, Search, Filter, Star } from "lucide-react"

// Mock data for products
const products = [
  {
    id: 1,
    name: "Premium Hair Wax",
    category: "styling",
    price: 24.99,
    rating: 4.8,
    image: "/placeholder.svg?height=300&width=300",
    description: "High-hold, low-shine hair wax for the perfect style.",
    inStock: true,
  },
  {
    id: 2,
    name: "Beard Oil",
    category: "beard",
    price: 19.99,
    rating: 4.6,
    image: "/placeholder.svg?height=300&width=300",
    description: "Nourishing beard oil for a soft, manageable beard.",
    inStock: true,
  },
  {
    id: 3,
    name: "Styling Brush",
    category: "accessories",
    price: 15.99,
    rating: 4.5,
    image: "/placeholder.svg?height=300&width=300",
    description: "Professional styling brush for perfect hair styling.",
    inStock: true,
  },
  {
    id: 4,
    name: "Premium Shampoo",
    category: "haircare",
    price: 22.99,
    rating: 4.7,
    image: "/placeholder.svg?height=300&width=300",
    description: "Sulfate-free shampoo for healthy, vibrant hair.",
    inStock: true,
  },
  {
    id: 5,
    name: "Beard Trimmer",
    category: "accessories",
    price: 49.99,
    rating: 4.9,
    image: "/placeholder.svg?height=300&width=300",
    description: "Precision beard trimmer for the perfect beard shape.",
    inStock: false,
  },
  {
    id: 6,
    name: "Hair Pomade",
    category: "styling",
    price: 21.99,
    rating: 4.4,
    image: "/placeholder.svg?height=300&width=300",
    description: "Medium-hold, high-shine pomade for classic styles.",
    inStock: true,
  },
  {
    id: 7,
    name: "Beard Balm",
    category: "beard",
    price: 18.99,
    rating: 4.3,
    image: "/placeholder.svg?height=300&width=300",
    description: "Conditioning beard balm for shape and control.",
    inStock: true,
  },
  {
    id: 8,
    name: "Hair Dryer",
    category: "accessories",
    price: 79.99,
    rating: 4.8,
    image: "/placeholder.svg?height=300&width=300",
    description: "Professional-grade hair dryer for quick, even drying.",
    inStock: true,
  },
]

export default function MarketPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeCategory, setActiveCategory] = useState("all")
  const [cart, setCart] = useState<{ id: number; quantity: number }[]>([])

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = activeCategory === "all" || product.category === activeCategory

    return matchesSearch && matchesCategory
  })

  const addToCart = (productId: number) => {
    const existingItem = cart.find((item) => item.id === productId)

    if (existingItem) {
      setCart(cart.map((item) => (item.id === productId ? { ...item, quantity: item.quantity + 1 } : item)))
    } else {
      setCart([...cart, { id: productId, quantity: 1 }])
    }
  }

  const cartItemCount = cart.reduce((total, item) => total + item.quantity, 0)
  const cartTotal = cart.reduce((total, item) => {
    const product = products.find((p) => p.id === item.id)
    return total + (product ? product.price * item.quantity : 0)
  }, 0)

  return (
    <div className="flex min-h-screen flex-col">
      <MainNav />
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Shop</h2>
            <p className="text-muted-foreground">Browse our selection of premium grooming products</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search products..."
                className="w-full md:w-[200px] pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
              <span className="sr-only">Filter</span>
            </Button>
            <Button variant="outline" className="relative">
              <ShoppingCart className="h-4 w-4 mr-2" />
              <span>Cart</span>
              {cartItemCount > 0 && (
                <Badge className="absolute -top-2 -right-2 px-1 min-w-[20px] h-5 flex items-center justify-center">
                  {cartItemCount}
                </Badge>
              )}
            </Button>
          </div>
        </div>

        <Tabs defaultValue="all" value={activeCategory} onValueChange={setActiveCategory}>
          <TabsList>
            <TabsTrigger value="all">All Products</TabsTrigger>
            <TabsTrigger value="styling">Styling</TabsTrigger>
            <TabsTrigger value="beard">Beard Care</TabsTrigger>
            <TabsTrigger value="haircare">Hair Care</TabsTrigger>
            <TabsTrigger value="accessories">Accessories</TabsTrigger>
          </TabsList>

          <TabsContent value={activeCategory} className="mt-6">
            {filteredProducts.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground">No products found matching your criteria.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {filteredProducts.map((product) => (
                  <Card key={product.id} className="overflow-hidden">
                    <div className="aspect-square relative">
                      <img
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        className="object-cover w-full h-full"
                      />
                      {!product.inStock && (
                        <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
                          <Badge variant="destructive" className="text-sm">
                            Out of Stock
                          </Badge>
                        </div>
                      )}
                    </div>
                    <CardHeader className="p-4">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{product.name}</CardTitle>
                        <div className="flex items-center">
                          <Star className="h-3 w-3 fill-primary text-primary mr-1" />
                          <span className="text-sm">{product.rating}</span>
                        </div>
                      </div>
                      <CardDescription className="mt-2">{product.description}</CardDescription>
                    </CardHeader>
                    <CardFooter className="p-4 pt-0 flex justify-between items-center">
                      <div className="font-medium">${product.price.toFixed(2)}</div>
                      <Button size="sm" disabled={!product.inStock} onClick={() => addToCart(product.id)}>
                        Add to Cart
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        {cartItemCount > 0 && (
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Your Cart</CardTitle>
              <CardDescription>
                You have {cartItemCount} item{cartItemCount !== 1 ? "s" : ""} in your cart
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {cart.map((item) => {
                  const product = products.find((p) => p.id === item.id)
                  if (!product) return null

                  return (
                    <div key={item.id} className="flex justify-between items-center">
                      <div className="flex items-center gap-4">
                        <img
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          className="h-12 w-12 object-cover rounded"
                        />
                        <div>
                          <p className="font-medium">{product.name}</p>
                          <p className="text-sm text-muted-foreground">
                            Qty: {item.quantity} × ${product.price.toFixed(2)}
                          </p>
                        </div>
                      </div>
                      <div className="font-medium">${(product.price * item.quantity).toFixed(2)}</div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
            <CardFooter className="flex justify-between border-t pt-4">
              <div>
                <p className="font-medium">Total</p>
                <p className="text-sm text-muted-foreground">Shipping calculated at checkout</p>
              </div>
              <div className="text-right">
                <p className="font-medium">${cartTotal.toFixed(2)}</p>
                <Button className="mt-2">Checkout</Button>
              </div>
            </CardFooter>
          </Card>
        )}
      </div>
    </div>
  )
}

