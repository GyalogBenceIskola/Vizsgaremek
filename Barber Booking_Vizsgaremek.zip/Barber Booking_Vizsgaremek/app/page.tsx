import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Scissors, Calendar, ShoppingBag, ArrowRight } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="flex items-center gap-2 font-bold text-xl">
            <Scissors className="h-6 w-6" />
            <span>BarberBook</span>
          </Link>
          <nav className="hidden md:flex gap-6">
            <Link href="/booking" className="text-sm font-medium hover:underline underline-offset-4">
              Book Now
            </Link>
            <Link href="/market" className="text-sm font-medium hover:underline underline-offset-4">
              Shop
            </Link>
            <Link href="/about" className="text-sm font-medium hover:underline underline-offset-4">
              About
            </Link>
          </nav>
          <div className="flex gap-4">
            <Link href="/auth/login">
              <Button variant="outline" size="sm">
                Log in
              </Button>
            </Link>
            <Link href="/auth/register">
              <Button size="sm">Register</Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="space-y-4">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Book Your Next Haircut with Ease
                </h1>
                <p className="text-muted-foreground md:text-xl">
                  Choose your barber, select a time, and get the perfect cut. No waiting, no hassle.
                </p>
                <div className="flex flex-col gap-2 sm:flex-row">
                  <Link href="/booking">
                    <Button size="lg" className="gap-2">
                      Book Now <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="/market">
                    <Button variant="outline" size="lg">
                      Shop Products
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="rounded-lg overflow-hidden">
                <img
                  src="/placeholder.svg?height=550&width=700"
                  alt="Barber shop interior"
                  className="aspect-video object-cover w-full"
                />
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Our Services</h2>
                <p className="text-muted-foreground md:text-xl">
                  Everything you need for the perfect grooming experience
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
              <div className="flex flex-col items-center space-y-4 p-6 border rounded-lg">
                <div className="p-3 rounded-full bg-primary/10">
                  <Calendar className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Easy Booking</h3>
                <p className="text-center text-muted-foreground">
                  Book appointments with your favorite barbers at your convenience
                </p>
              </div>
              <div className="flex flex-col items-center space-y-4 p-6 border rounded-lg">
                <div className="p-3 rounded-full bg-primary/10">
                  <ShoppingBag className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Premium Products</h3>
                <p className="text-center text-muted-foreground">
                  Shop for high-quality hair care products and grooming accessories
                </p>
              </div>
              <div className="flex flex-col items-center space-y-4 p-6 border rounded-lg">
                <div className="p-3 rounded-full bg-primary/10">
                  <Scissors className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold">Expert Barbers</h3>
                <p className="text-center text-muted-foreground">
                  Get your hair cut by experienced professionals who know their craft
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t py-6 md:py-8">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4 px-4 md:px-6">
          <div className="flex items-center gap-2">
            <Scissors className="h-5 w-5" />
            <span className="font-semibold">BarberBook</span>
          </div>
          <p className="text-sm text-muted-foreground">© 2024 BarberBook. All rights reserved.</p>
          <nav className="flex gap-4">
            <Link href="/about" className="text-sm text-muted-foreground hover:underline underline-offset-4">
              About
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground hover:underline underline-offset-4">
              Privacy
            </Link>
            <Link href="/terms" className="text-sm text-muted-foreground hover:underline underline-offset-4">
              Terms
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}

