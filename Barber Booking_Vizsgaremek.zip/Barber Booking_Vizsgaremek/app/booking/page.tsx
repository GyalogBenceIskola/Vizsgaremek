"use client"

import { useState } from "react"
import { MainNav } from "@/components/main-nav"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { format } from "date-fns"
import { CalendarIcon, Clock, Check } from "lucide-react"
import { useRouter } from "next/navigation"

// Mock data for barbers
const barbers = [
  { id: 1, name: "John Doe", specialty: "Classic Cuts", image: "/placeholder.svg?height=100&width=100" },
  { id: 2, name: "Sarah Smith", specialty: "Modern Styles", image: "/placeholder.svg?height=100&width=100" },
  { id: 3, name: "Mike Johnson", specialty: "Beard Grooming", image: "/placeholder.svg?height=100&width=100" },
  { id: 4, name: "Emily Davis", specialty: "Fades & Tapers", image: "/placeholder.svg?height=100&width=100" },
]

// Mock data for services
const services = [
  { id: 1, name: "Haircut", duration: "30 min", price: "$25" },
  { id: 2, name: "Haircut & Beard Trim", duration: "45 min", price: "$35" },
  { id: 3, name: "Premium Haircut", duration: "45 min", price: "$40" },
  { id: 4, name: "Beard Trim", duration: "15 min", price: "$15" },
  { id: 5, name: "Head Shave", duration: "30 min", price: "$30" },
  { id: 6, name: "Kids Haircut", duration: "20 min", price: "$20" },
]

// Mock data for time slots
const timeSlots = [
  "9:00 AM",
  "9:30 AM",
  "10:00 AM",
  "10:30 AM",
  "11:00 AM",
  "11:30 AM",
  "12:00 PM",
  "12:30 PM",
  "1:00 PM",
  "1:30 PM",
  "2:00 PM",
  "2:30 PM",
  "3:00 PM",
  "3:30 PM",
  "4:00 PM",
  "4:30 PM",
  "5:00 PM",
  "5:30 PM",
]

export default function BookingPage() {
  const router = useRouter()
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [selectedBarber, setSelectedBarber] = useState<number | null>(null)
  const [selectedService, setSelectedService] = useState<number | null>(null)
  const [selectedTime, setSelectedTime] = useState<string | null>(null)
  const [bookingStep, setBookingStep] = useState(1)
  const [isLoading, setIsLoading] = useState(false)

  const handleBookAppointment = () => {
    setIsLoading(true)

    // Simulate booking process
    setTimeout(() => {
      setIsLoading(false)
      router.push("/dashboard?booking=success")
    }, 1500)
  }

  const nextStep = () => {
    setBookingStep(bookingStep + 1)
  }

  const prevStep = () => {
    setBookingStep(bookingStep - 1)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <MainNav />
      <div className="flex-1 space-y-4 p-4 md:p-8 pt-6">
        <div className="flex items-center justify-between">
          <h2 className="text-3xl font-bold tracking-tight">Book an Appointment</h2>
        </div>

        <div className="grid gap-4 md:grid-cols-7">
          <div className="md:col-span-5">
            <Card>
              <CardHeader>
                <CardTitle>Booking Steps</CardTitle>
                <CardDescription>Follow the steps to book your appointment</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs value={`step-${bookingStep}`} className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="step-1" disabled={bookingStep !== 1}>
                      1. Select Service
                    </TabsTrigger>
                    <TabsTrigger value="step-2" disabled={bookingStep !== 2}>
                      2. Choose Barber
                    </TabsTrigger>
                    <TabsTrigger value="step-3" disabled={bookingStep !== 3}>
                      3. Date & Time
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="step-1" className="space-y-4 py-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {services.map((service) => (
                        <div
                          key={service.id}
                          className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                            selectedService === service.id ? "border-primary bg-primary/5" : "hover:border-primary/50"
                          }`}
                          onClick={() => setSelectedService(service.id)}
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-medium">{service.name}</h3>
                              <p className="text-sm text-muted-foreground">{service.duration}</p>
                            </div>
                            <div className="font-medium">{service.price}</div>
                          </div>
                          {selectedService === service.id && (
                            <div className="flex justify-end mt-2">
                              <Check className="h-4 w-4 text-primary" />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-end">
                      <Button onClick={nextStep} disabled={!selectedService}>
                        Continue
                      </Button>
                    </div>
                  </TabsContent>

                  <TabsContent value="step-2" className="space-y-4 py-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {barbers.map((barber) => (
                        <div
                          key={barber.id}
                          className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                            selectedBarber === barber.id ? "border-primary bg-primary/5" : "hover:border-primary/50"
                          }`}
                          onClick={() => setSelectedBarber(barber.id)}
                        >
                          <div className="flex gap-4">
                            <img
                              src={barber.image || "/placeholder.svg"}
                              alt={barber.name}
                              className="h-16 w-16 rounded-full object-cover"
                            />
                            <div>
                              <h3 className="font-medium">{barber.name}</h3>
                              <p className="text-sm text-muted-foreground">{barber.specialty}</p>
                            </div>
                            {selectedBarber === barber.id && (
                              <div className="ml-auto">
                                <Check className="h-4 w-4 text-primary" />
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-between">
                      <Button variant="outline" onClick={prevStep}>
                        Back
                      </Button>
                      <Button onClick={nextStep} disabled={!selectedBarber}>
                        Continue
                      </Button>
                    </div>
                  </TabsContent>

                  <TabsContent value="step-3" className="space-y-4 py-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="font-medium mb-2 flex items-center gap-2">
                          <CalendarIcon className="h-4 w-4" /> Select Date
                        </h3>
                        <Calendar
                          mode="single"
                          selected={date}
                          onSelect={setDate}
                          className="border rounded-md"
                          disabled={(date) => {
                            // Disable past dates and Sundays
                            const today = new Date()
                            today.setHours(0, 0, 0, 0)
                            return date < today || date.getDay() === 0
                          }}
                        />
                      </div>
                      <div>
                        <h3 className="font-medium mb-2 flex items-center gap-2">
                          <Clock className="h-4 w-4" /> Select Time
                        </h3>
                        <div className="grid grid-cols-3 gap-2">
                          {timeSlots.map((time) => (
                            <Button
                              key={time}
                              variant={selectedTime === time ? "default" : "outline"}
                              className="w-full"
                              onClick={() => setSelectedTime(time)}
                            >
                              {time}
                            </Button>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="flex justify-between">
                      <Button variant="outline" onClick={prevStep}>
                        Back
                      </Button>
                      <Button onClick={handleBookAppointment} disabled={!date || !selectedTime || isLoading}>
                        {isLoading ? "Booking..." : "Book Appointment"}
                      </Button>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Booking Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {selectedService && (
                  <div className="space-y-1">
                    <p className="text-sm font-medium">Service</p>
                    <p className="text-sm">
                      {services.find((s) => s.id === selectedService)?.name} -{" "}
                      {services.find((s) => s.id === selectedService)?.price}
                    </p>
                  </div>
                )}

                {selectedBarber && (
                  <div className="space-y-1">
                    <p className="text-sm font-medium">Barber</p>
                    <p className="text-sm">{barbers.find((b) => b.id === selectedBarber)?.name}</p>
                  </div>
                )}

                {date && (
                  <div className="space-y-1">
                    <p className="text-sm font-medium">Date</p>
                    <p className="text-sm">{format(date, "EEEE, MMMM d, yyyy")}</p>
                  </div>
                )}

                {selectedTime && (
                  <div className="space-y-1">
                    <p className="text-sm font-medium">Time</p>
                    <p className="text-sm">{selectedTime}</p>
                  </div>
                )}
              </CardContent>
              {selectedService && (
                <CardFooter className="border-t pt-4">
                  <div className="space-y-1 w-full">
                    <div className="flex justify-between">
                      <p className="font-medium">Total</p>
                      <p className="font-medium">{services.find((s) => s.id === selectedService)?.price}</p>
                    </div>
                    <p className="text-xs text-muted-foreground">Payment will be collected at the shop</p>
                  </div>
                </CardFooter>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

