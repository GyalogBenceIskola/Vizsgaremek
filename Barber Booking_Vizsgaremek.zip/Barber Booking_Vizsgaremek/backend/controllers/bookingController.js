import db from "../config/db.js";

export async function createBooking(req, res) {
  const { service, date } = req.body;
  await db.query("INSERT INTO bookings (user_id, service, date) VALUES (?, ?, ?)", [req.user.id, service, date]);
  res.json({ message: "Foglalás mentve" });
}

export async function getBookings(req, res) {
  const [rows] = await db.query("SELECT * FROM bookings WHERE user_id = ?", [req.user.id]);
  res.json(rows);
}
