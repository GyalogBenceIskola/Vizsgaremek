import db from "../config/db.js";

export async function getAllProducts(req, res) {
  const [rows] = await db.query("SELECT * FROM products");
  res.json(rows);
}

export async function addProduct(req, res) {
  const { name, price } = req.body;
  await db.query("INSERT INTO products (name, price) VALUES (?, ?)", [name, price]);
  res.json({ message: "Termék hozzáadva" });
}

export async function deleteProduct(req, res) {
  const { id } = req.params;
  await db.query("DELETE FROM products WHERE id = ?", [id]);
  res.json({ message: "Termék törölve" });
}
