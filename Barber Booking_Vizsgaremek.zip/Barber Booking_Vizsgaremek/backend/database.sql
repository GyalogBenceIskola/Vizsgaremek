CREATE DATABASE IF NOT EXISTS barberdb;
USE barberdb;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100) UNIQUE,
  password VARCHAR(255)
);

CREATE TABLE services (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  duration_minutes INT,
  price INT
);

CREATE TABLE bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  service_id INT,
  date DATETIME,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (service_id) REFERENCES services(id)
);

CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  price INT
);

CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT,
  product_id INT,
  quantity INT,
  order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (product_id) REFERENCES products(id)
);

DELIMITER //

CREATE TRIGGER limit_bookings_per_day
BEFORE INSERT ON bookings
FOR EACH ROW
BEGIN
  DECLARE booking_count INT;

  SELECT COUNT(*) INTO booking_count
  FROM bookings
  WHERE DATE(date) = DATE(NEW.date);

  IF booking_count >= 10 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Maximum 10 foglalás engedélyezett egy napra.';
  END IF;
END;
//

CREATE FUNCTION total_spent_by_user(userId INT) RETURNS INT
DETERMINISTIC
BEGIN
  DECLARE total INT;

  SELECT SUM(p.price * o.quantity) INTO total
  FROM orders o
  JOIN products p ON o.product_id = p.id
  WHERE o.user_id = userId;

  RETURN IFNULL(total, 0);
END;
//

CREATE FUNCTION total_bookings_by_user(userId INT) RETURNS INT
DETERMINISTIC
BEGIN
  DECLARE total INT;

  SELECT COUNT(*) INTO total
  FROM bookings
  WHERE user_id = userId;

  RETURN total;
END;
//

DELIMITER ;
